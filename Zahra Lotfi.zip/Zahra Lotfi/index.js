const questions = document.querySelectorAll("#q");
const answers = ["answer1", "answer2"];
const inputs = document.querySelectorAll("#inputQ");

// const showAnswers = document.querySelectorAll("#showAnswer");
// console.log("its questions", questions);
// console.log("its inputs", inputs);

const btn1 = document.querySelector("#showAnswer1");
btn1.addEventListener("click", () => {
  inputs[0].value = answers[0];
});

const btn2 = document.querySelector("#showAnswer2");
btn2.addEventListener("click", () => {
  inputs[1].value = answers[1];
});
